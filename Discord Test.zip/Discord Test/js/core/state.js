// js/core/state.js

const state = {
  user: null,            // PlayFab user info
  playFabId: null,

  photon: {
    connected: false,
    room: null,
    userId: null
  },

  voice: {
    enabled: false,
    muted: false,
    speaking: false
  },

  chat: {
    currentRoom: "general",
    currentDM: null,
    messages: []
  }
};

export default state;