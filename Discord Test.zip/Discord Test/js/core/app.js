// js/core/app.js

import state from "./state.js";
import { loginPlayFab } from "../auth/auth.js";

import photon, { setupPhotonListeners } from "../network/photon.js";
import voice from "../network/voice.js";

import { handleIncomingMessage } from "../chat/chat.js";

export async function startApp(username) {

  console.log("🚀 Starting app...");

  // 🟢 1. LOGIN FIRST (PlayFab)
  const user = await loginPlayFab(username);

  state.user = user;
  state.playFabId = user.PlayFabId;

  console.log("✅ Logged in:", state.playFabId);

  // 🟢 2. CONNECT PHOTON
  photon.connectPhoton(state.playFabId);

  setupPhotonListeners((event) => {
    handleIncomingMessage(event);
  });

  // 🟢 3. WAIT FOR ROOM (safer than fixed timeout)
  const waitForRoom = setInterval(() => {

    const room = state.chat.currentRoom || "general";

    if (state.photon.connected) {

      clearInterval(waitForRoom);

      voice.connectVoice(state.playFabId, room);
      voice.startMicrophone();
    }

  }, 300);

  console.log("🎮 App starting...");
}

export default { startApp };