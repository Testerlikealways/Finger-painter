// js/core/config.js

export const CONFIG = {
  PLAYFAB_TITLE_ID: "9B85A",

  PHOTON: {
    CHAT_APP_ID: "97c62c77-1f37-4d04-ba73-40f8b2afc4a1",
    REALTIME_APP_ID: "c0f26cd3-a89c-40a3-86d8-b98926648caa",
    VOICE_APP_ID: "805ffcc0-7b9a-4f90-bdb3-5915d86cf178"
  }
};