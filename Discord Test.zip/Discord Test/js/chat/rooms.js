// js/chat/rooms.js

import state from "../core/state.js";
import photon from "../network/photon.js";

export function joinRoom(roomName) {

  state.chat.currentRoom = roomName;
  state.chat.currentDM = null;

  photon.joinRoom(roomName);
}
