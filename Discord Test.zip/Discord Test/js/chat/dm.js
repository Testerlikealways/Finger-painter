// js/chat/dm.js

import state from "../core/state.js";
import photon from "../network/photon.js";

/**
 * Always creates same room for both users
 */
export function createDM(userA, userB) {
  return [userA, userB].sort().join("_");
}
// js/chat/dm.js

export function openDM(targetUser) {

  const room = createDM(state.playFabId, targetUser);

  state.chat.currentDM = room;
  state.chat.currentRoom = null;

  photon.joinRoom(room);
}
// js/chat/dm.js

export function exitDM() {
  state.chat.currentDM = null;
  state.chat.currentRoom = "general";

  photon.joinRoom("general");
}

