// js/chat/chat.js

import state from "../core/state.js";
import photon from "../network/photon.js";
import { sendDMMessageToStorage } from "../network/chatSync.js";

/**
 * MAIN ENTRY POINT FOR ALL MESSAGES
 */
export function sendChatMessage(text) {

  const message = {
    sender: state.playFabId,
    text,
    timestamp: Date.now(),
    room: state.chat.currentRoom,
    dm: state.chat.currentDM
  };

  // 💬 DM MODE
  if (state.chat.currentDM) {
    sendDM(message);
    return;
  }

  // 🏠 ROOM MODE
  sendRoom(message);
}
// js/chat/chat.js

function sendRoom(message) {
  photon.sendMessage({
    type: "room-message",
    data: message
  });

  state.chat.messages.push(message);
}
// js/chat/chat.js

function sendDM(message) {

  const roomName = state.chat.currentDM;

  photon.sendMessage({
    type: "dm-message",
    room: roomName,
    data: message
  });

  sendDMMessageToStorage(roomName, message);

  state.chat.messages.push(message);
}