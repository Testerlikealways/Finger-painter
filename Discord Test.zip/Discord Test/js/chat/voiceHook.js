// js/chat/voiceHook.js

import voice from "../network/voice.js";
import state from "../core/state.js";

/**
 * Call this whenever room changes
 */
export function syncVoiceWithRoom() {

  if (!state.voice.enabled) return;

  voice.connectVoice(
    state.playFabId,
    state.chat.currentDM || state.chat.currentRoom
  );
}