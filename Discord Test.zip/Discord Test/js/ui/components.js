// js/ui/components.js

export function createMessageElement(message) {

  const div = document.createElement("div");
  div.className = "message";

  const sender = document.createElement("strong");
  sender.textContent = message.sender;

  const text = document.createTextNode(`: ${message.text}`);

  div.appendChild(sender);
  div.appendChild(text);

  return div;
}

export function createUserElement(user, onClick) {

  const div = document.createElement("div");

  div.className = "user";
  div.innerText = user;

  div.onclick = () => {
    if (onClick) onClick(user);
  };

  return div;
}