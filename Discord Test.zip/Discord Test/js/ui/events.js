// js/ui/events.js
import { sendChatMessage } from "../chat/chat.js";
import { openDM } from "../chat/dm.js";

export function setupChatInput() {

  const input = document.getElementById("chatInput");
  if (!input) return;

  input.addEventListener("keydown", (e) => {

    if (e.isComposing) return;

    if (e.key === "Enter") {
      e.preventDefault();

      const value = input.value.trim();
      if (!value) return;

      sendChatMessage(value);
      input.value = "";
    }
  });
}

export function setupUserClick(renderUsersCallback) {

  if (typeof renderUsersCallback !== "function") return;

  renderUsersCallback((user) => {
    openDM(user);
  });
}