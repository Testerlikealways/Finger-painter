// js/ui/ui.js

import state from "../core/state.js";
import { createMessageElement, createUserElement } from "./components.js";

const chatBox = document.getElementById("chatBox");
const userList = document.getElementById("userList");

export function renderChat() {

  if (!chatBox) return;
  if (!state.chat?.messages) return;

  chatBox.innerHTML = "";

  state.chat.messages.forEach(msg => {
    chatBox.appendChild(createMessageElement(msg));
  });
}

export function addMessage(msg) {

  if (!chatBox) return;
  if (!state.chat?.messages) state.chat.messages = [];

  state.chat.messages.push(msg);

  chatBox.appendChild(createMessageElement(msg));
}

export function renderUsers(users, onSelect) {

  if (!userList) return;

  userList.innerHTML = "";

  users.forEach(user => {
    userList.appendChild(createUserElement(user, onSelect));
  });
}