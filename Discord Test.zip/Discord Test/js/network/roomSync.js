import state from "../core/state.js";

/**
 * SAVE ROOM MESSAGE
 */
export function saveRoomMessageToStorage(roomName, message) {

  if (!window.PlayFabClientSDK) return;

  const key = "room_" + roomName;

  const request = {
    Data: {
      [key]: JSON.stringify(message)
    }
  };

  window.PlayFabClientSDK.UpdateUserData(
    request,
    () => {
      console.log("🏠 Room message saved:", roomName);
    },
    (error) => {
      console.error("❌ Room save failed:", error);
    }
  );
}

export function loadRoomHistory(roomName, callback) {

  if (!window.PlayFabClientSDK) {
    callback([]);
    return;
  }

  const key = "room_" + roomName;

  const request = {
    Keys: [key]
  };

  window.PlayFabClientSDK.GetUserData(
    request,
    (result) => {

      const data = result?.data?.Data?.[key];

      if (!data) {
        callback([]);
        return;
      }

      try {
        callback(JSON.parse(data.Value));
      } catch (e) {
        console.error("Parse error:", e);
        callback([]);
      }
    },
    (error) => {
      console.error("❌ Room load failed:", error);
      callback([]);
    }
  );
}