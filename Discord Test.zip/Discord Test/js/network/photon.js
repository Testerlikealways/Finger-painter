// js/network/photon.js

import state from "../core/state.js";
import { CONFIG } from "../core/config.js";

let client = null;
export function connectPhoton(userId) {

  client = new Photon.Realtime.LoadBalancingClient();

  client.appId = CONFIG.PHOTON_REALTIME_APP_ID;
  client.userId = userId;

  client.connectToRegionMaster(CONFIG.REGION);

  client.onConnectedToMaster = () => {
    console.log("🌐 Photon connected");

    state.photon.connected = true;

    joinRoom("general");
  };

  client.onJoinRoom = (room) => {
    console.log("📡 Joined room:", room.name);

    state.photon.room = room.name;
  };
}
export function joinRoom(roomName) {

  if (!client) return;

  client.joinRoom(roomName);

  state.photon.room = roomName;
}
export function sendMessage(payload) {

  if (!client) return;

  client.raiseEvent(1, payload);
}
export function setupPhotonListeners(onMessage) {

  client.onEvent = (code, content, actorNr) => {

    // Only handle chat events
    if (code !== 1) return;

    onMessage({
      ...content,
      actorNr
    });
  };
}
export default {
  connectPhoton,
  joinRoom,
  sendMessage,
  setupPhotonListeners
};