// js/network/voice.js

import state from "../core/state.js";
import { CONFIG } from "../core/config.js";

let voiceClient = null;
let localRecorder = null;

export function connectVoice(userId, roomName) {

  voiceClient = new Photon.Voice.LoadBalancingClient();

  voiceClient.appId = CONFIG.PHOTON_VOICE_APP_ID;
  voiceClient.userId = userId;

  voiceClient.connectToRegionMaster(CONFIG.REGION);

  voiceClient.onConnectedToMaster = () => {
    console.log("🎤 Voice connected");

    voiceClient.joinRoom(roomName);
  };

  voiceClient.onJoinedRoom = () => {
    console.log("🎧 Voice joined room");

    state.voice.enabled = true;
  };
}

// FIX: correct Photon Voice pattern (no fake event streaming)
export function startMicrophone() {

  if (!voiceClient) return;

  localRecorder = new Photon.Voice.LocalRecorder();

  // FIX: do NOT manually send frames via raiseEvent
  localRecorder.onAudioFrame = (frame) => {

    if (state.voice.muted) return;

    // Photon Voice should handle streaming internally
    voiceClient.sendFrame?.(frame);
  };

  localRecorder.start();
}

export function toggleMute() {
  state.voice.muted = !state.voice.muted;
}

export function syncVoiceRoom(roomName) {
  if (!voiceClient) return;
  voiceClient.joinRoom(roomName);
}

export default {
  connectVoice,
  startMicrophone,
  toggleMute,
  syncVoiceRoom
};