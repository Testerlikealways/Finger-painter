// js/network/sync.js

import state from "../core/state.js";
import { sendDMMessageToStorage, loadDMHistory } from "./chatSync.js";
import { saveRoomMessageToStorage, loadRoomHistory } from "./roomSync.js";
export function saveMessage(roomName, message, isDM = false) {

  if (isDM) {
    sendDMMessageToStorage(roomName, message);
    return;
  }

  // 🏠 ROOM HISTORY
  saveRoomMessageToStorage(roomName, message);
}
export function loadHistory(roomName, isDM = false, callback) {

  if (isDM) {
    loadDMHistory(roomName, callback);
    return;
  }

  // 🏠 ROOM HISTORY
  loadRoomHistory(roomName, callback);
}