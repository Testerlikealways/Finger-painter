import state from "../core/state.js";
import { CONFIG } from "../core/config.js";

export async function loginPlayFab(username) {
  return new Promise((resolve, reject) => {

    const request = {
      TitleId: CONFIG.PLAYFAB_TITLE_ID,
      Username: username,
      CreateAccount: true
    };

    PlayFabClientSDK.LoginWithCustomID(request, (result, error) => {
      if (error) {
        console.error("Login failed", error);
        reject(error);
        return;
      }

      state.user = result.data;
      state.playFabId = result.data.PlayFabId;

      console.log("Logged in:", state.playFabId);

      resolve(result.data);
    });
  });
}